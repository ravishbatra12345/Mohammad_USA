//console.log("Hello from javascript file");
//console is available on both client and server 


//This function is not using any API like console. It is a pure javascript
//In a javascript file, don't use APIs like console,document etc
function Addition(number1, number2)
{
    var sum = number1 + number2;
    return sum;
}