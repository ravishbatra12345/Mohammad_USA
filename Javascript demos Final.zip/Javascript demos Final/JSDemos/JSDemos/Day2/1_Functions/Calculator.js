
var $ = (function (){
    var Add = function(x,y){
        return x + y;
    }
    var Sub = function(x,y){
        return x - y;
    }
    var Mul = function(x,y){
        return x * y;
    }
    var Div = function(x,y){
        return x/ y;
    }

//If I have to reveal Add,sub etc to the outside world . Mul and Div are private whereas Add and Sub are public 
    return {
         Addition : Add,
         Substract : Sub
    }
})();